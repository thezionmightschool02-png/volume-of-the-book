// Central project configuration. Replace only these values when the official
// community/contact/giving destinations are available.
const CONFIG = {
  whatsappUrl: '',
  contactUrl: '',
  givingUrl: ''
};

(() => {
  const menuToggle = document.getElementById('menuToggle');
  const siteMenu = document.getElementById('siteMenu');
  const video = document.getElementById('zionPromo');
  const dialog = document.getElementById('siteDialog');
  const dialogTitle = document.getElementById('dialogTitle');
  const dialogText = document.getElementById('dialogText');
  const dialogLink = document.getElementById('dialogLink');
  const dialogClose = document.getElementById('dialogClose');

  if (menuToggle && siteMenu) {
    menuToggle.addEventListener('click', () => {
      const open = siteMenu.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', String(open));
    });
    siteMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      siteMenu.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
    }));
  }

  if (video && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          video.muted = true;
          video.play().catch(() => {});
        } else {
          video.pause();
        }
      });
    }, { threshold: 0.45 });
    observer.observe(video);

    video.addEventListener('click', () => {
      if (video.paused) video.play().catch(() => {});
      video.muted = !video.muted;
    });
  }

  function openAction(kind) {
    const actions = {
      whatsapp: {
        title: 'WhatsApp Community',
        text: 'Add the official WhatsApp community link in CONFIG.whatsappUrl in js/app.js.',
        url: CONFIG.whatsappUrl
      },
      contact: {
        title: 'Contact the Community',
        text: 'Add the official contact destination in CONFIG.contactUrl in js/app.js.',
        url: CONFIG.contactUrl
      },
      give: {
        title: 'Give / Support',
        text: 'Add the official giving destination in CONFIG.givingUrl in js/app.js.',
        url: CONFIG.givingUrl
      }
    };
    const action = actions[kind];
    if (!action) return;
    if (action.url) {
      window.open(action.url, '_blank', 'noopener');
      return;
    }
    dialogTitle.textContent = action.title;
    dialogText.textContent = action.text;
    dialogLink.hidden = true;
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else alert(action.text);
  }

  document.querySelectorAll('[data-action]').forEach(button => {
    button.addEventListener('click', () => openAction(button.dataset.action));
  });

  dialogClose?.addEventListener('click', () => dialog.close());
  dialog?.addEventListener('click', event => {
    if (event.target === dialog) dialog.close();
  });
})();
