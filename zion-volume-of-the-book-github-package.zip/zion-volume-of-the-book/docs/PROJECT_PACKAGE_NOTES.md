# Project Package Notes

This package is a continuation layer intended to keep the known project information intact while adding the website files needed for a functioning static repository.

Known project facts carried forward:
- Repository: `thezionmightschool02-png/volume-of-the-book`
- Promotional video duration: 42 seconds.
- Target video: approximately 25 MB, compressing the video itself rather than creating a separate audio file.
- Video dimensions: 1920×1080.
- Video includes voiceover and cinematic background audio.
- Poster/visual asset: the supplied golden heavenly gathering image is included in `assets/`.
- The site is responsive and includes navigation, community/WhatsApp actions, giving interactions, and mobile behavior.
- The original 1920×1080 visual source is retained; the audio is the new layer for the promo.
