# GitHub Upload Instructions

## Repository
`thezionmightschool02-png/volume-of-the-book`

Upload the contents of this package to the repository root.

## Required final asset
Before publishing, place the real promotional video at:
`assets/zion_might_42s_promo_github.mp4`

Do not rename it unless you also update the `<source>` element in `index.html`.

## Description
The Volume of the Book — The Path of Life: a responsive Zion Might School static website with the 42-second promotional video integration, community actions, giving action, mobile navigation, and supplied visual assets.

## Commit message
`Build responsive Volume of the Book site and integrate Zion Might promo video`

## Publish
For GitHub Pages, publish the repository from the branch/folder containing `index.html`.
