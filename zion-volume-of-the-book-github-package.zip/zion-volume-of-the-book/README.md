# The Volume of the Book — The Path of Life

Repository package for the Zion Might School / The Zion Might web project.

## Repository
`thezionmightschool02-png/volume-of-the-book`

## Included
- `index.html` — responsive landing page and content sections.
- `css/styles.css` — responsive styling and video presentation.
- `js/app.js` — mobile navigation, autoplay-on-scroll, tap-for-sound, and configurable WhatsApp/contact/giving actions.
- `assets/golden-gathering-heavenly-city.png` — supplied heavenly gathering visual.
- `assets/VIDEO_PLACEHOLDER.txt` — documents the required 42-second promo asset.
- `docs/` — preserved video integration and voiceover timing documentation.

## Video asset
The repository expects `assets/zion_might_42s_promo_github.mp4`. The actual MP4 was not available to this packaging step, so it is intentionally not fabricated or substituted. Copy the real 42-second 1920×1080 MP4 into `assets/` using that exact filename.

The video is designed to:
- autoplay when approximately 45% visible, muted;
- pause when scrolled away;
- toggle sound when clicked/tapped;
- remain inline on mobile;
- show the supplied poster image before playback.

## Configure official links
Open `js/app.js` and fill in:
- `whatsappUrl`
- `contactUrl`
- `givingUrl`

No account details, payment destination, or community URL has been invented in this package.

## GitHub Pages
This is a static site and can be published directly from the repository. The entry point is `index.html`.

## Existing project information preserved
The supplied project documentation describes the 42-second voiceover and visual timing, including:
- 0.0–4.0s fellowship / people studying;
- 4.0–13.8s Volume of the Book introduction and beginning / humanity / Christ / Kingdom of God;
- 13.8–28.1s wider community and transformation;
- 28.1–32.1s young people holding the books;
- 32.1–36.1s older villagers/community holding the books;
- 36.1–38.3s children/community;
- 38.3–42.0s book close and invitation.

The documented voiceover begins: “Every life is a journey. But every journey needs a path.” and closes with the invitation to open the Volume of the Book and discover the path of life.
